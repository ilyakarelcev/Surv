using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Joystick : MonoBehaviour
{

    [SerializeField] RectTransform _joystickRect;
    [SerializeField] Transform _stickTransform;
    private Vector2 _startClickPosition;

    public Vector2 Value;

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) {
            _startClickPosition = Input.mousePosition;
            transform.position = _startClickPosition;
        }

        if (Input.GetMouseButton(0)) {
            Vector2 delta = (Vector2)Input.mousePosition - _startClickPosition;
            float radius = _joystickRect.sizeDelta.x / 2f;
            Vector2 clamed = Vector2.ClampMagnitude(delta, radius);
            _stickTransform.position = _startClickPosition + clamed;
            Value = clamed / radius;
        }

        if (Input.GetMouseButtonUp(0))
        {
            transform.position = new Vector3(Screen.width / 2, Screen.height / 5);
            _stickTransform.localPosition = Vector3.zero;
            Value = Vector2.zero;
        }
    }
}
