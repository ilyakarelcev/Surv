using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContinuousEffect : Effect
{
    public override void Create(EffectsManager effectsManager)
    {
        effectsManager.AddContinuousEffect(this);
    }

    public virtual void ProcessFrame(EffectsManager effectsManager, float frameTime) {
    }

}
