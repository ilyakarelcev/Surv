using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{

    private float _damage;
    [SerializeField] private Rigidbody _rigidbody;

    private void Start()
    {
        Destroy(gameObject, 3f);
    }

    public void Setup(Vector3 velocity, float damage) {
        _damage = damage;
        _rigidbody.velocity = velocity;
    }

    void Die()
    {
        Destroy(gameObject);
        //
    }

}
