using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{

    private Transform _playerTransform;
    [SerializeField] Rigidbody _rigidbody;
    [SerializeField] float _speed = 3f;

    public void Setup(Transform playerTransform) {
        _playerTransform = playerTransform;
    }

    private void Update()
    {
        Vector3 toPlayer = _playerTransform.position - transform.position;
        Quaternion targetRotation = Quaternion.LookRotation(toPlayer);
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, Time.deltaTime * 12f);
    }

    void FixedUpdate()
    {
        _rigidbody.velocity = transform.forward * _speed;
    }
}
