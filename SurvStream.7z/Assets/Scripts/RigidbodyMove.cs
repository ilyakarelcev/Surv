using UnityEngine;

public class RigidbodyMove : MonoBehaviour
{
    [SerializeField] private Rigidbody _rigidbody;
    [SerializeField] private float _speed = 5f;
    //[SerializeField] private float _rotationSpeed = 10f;
    [SerializeField] private Joystick _joystick;
    private Vector2 _moveInput;

    private void Update()
    {
        _moveInput = _joystick.Value;
        if (_rigidbody.velocity != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(_rigidbody.velocity, Vector3.up);
        }
    }

    private void FixedUpdate()
    {
        _rigidbody.velocity = new Vector3(_moveInput.x, 0, _moveInput.y) * _speed;
    }

    public void AddSpeed(float percen) {
        _speed *= 1f + percen;
    }

}
