using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectsManager : MonoBehaviour
{

    public RigidbodyMove RigidbodyMove;

    [SerializeField] private List<ContinuousEffect> _continuousEffectsList = new List<ContinuousEffect>();
    public void AddContinuousEffect(ContinuousEffect continuousEffect) {
        _continuousEffectsList.Add(continuousEffect);
    }

    public void AddEffect(Effect effect)
    {
        Effect newEffect = Instantiate(effect);
        newEffect.Create(this);
    }

    void Update()
    {
        foreach (var effect in _continuousEffectsList)
        {
            effect.ProcessFrame(this, Time.deltaTime);
        }
    }
}
