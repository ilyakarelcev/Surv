using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestAddEffet : MonoBehaviour
{

    [SerializeField] private EffectsManager _effectsManager;
    [SerializeField] private Effect _effect;


    [ContextMenu("Add")]
    public void Add()
    {
        _effectsManager.AddEffect(_effect);
    }


}
