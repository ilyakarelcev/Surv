using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class AxesEffect : Effect
{

    [SerializeField] private Axes _axesPrefab;

    public override void Create(EffectsManager effectsManager)
    {
        Axes axes = Instantiate(_axesPrefab);
        axes.Setup(effectsManager.transform);
    }

}
