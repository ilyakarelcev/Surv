using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class AddSpeedEffect : Effect
{
    [SerializeField] private float _percent;
    public override void Create(EffectsManager effectsManager)
    {
        effectsManager.RigidbodyMove.AddSpeed(_percent);
    }

}
