using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class QuadShotEffect : ContinuousEffect
{
    private float _timer;
    [Space(8)]
    [SerializeField] private float _shotPeriod;
    [SerializeField] private Bullet _bulletPrefab;
    [SerializeField] private float _damageValue;
    [SerializeField] private float _bulletSpeed;

    public override void ProcessFrame(EffectsManager effectsManager, float frameTime)
    {
        base.ProcessFrame(effectsManager, frameTime);
        _timer += frameTime;
        if (_timer > _shotPeriod) {
            _timer = 0;
            CreateBullets(effectsManager.transform);
        }
    }

    public void CreateBullets(Transform transform) {
        Vector3[] directions = {transform.right, -transform.right, transform.forward, -transform.forward};
        for (int i = 0; i < directions.Length; i++)
        {
            Bullet newBullet = Instantiate(_bulletPrefab, transform.position + Vector3.up, Quaternion.identity);
            newBullet.Setup(directions[i] * _bulletSpeed, _damageValue);
        }
    }

}
