using UnityEditor;
using UnityEngine;

public class EnemyManager : MonoBehaviour
{

    [SerializeField] private Enemy _enemyPrefab;
    [SerializeField] private Transform _playerTransform;
    [SerializeField] private float _creationPeriod;
    private float _timer;

    [SerializeField] private float _minRadius;
    [SerializeField] private float _maxRadius;

    void Update()
    {
        _timer += Time.deltaTime;
        if (_timer > _creationPeriod)
        {
            _timer = 0;
            CreteEnemy();
        }
    }

    private void CreteEnemy()
    {
        Vector2 randomVector = Random.insideUnitCircle;
        Vector2 randomPoint = randomVector.normalized * Random.Range(_minRadius, _maxRadius);
        Vector3 randomPointXZ = new Vector3(randomPoint.x, 0, randomPoint.y);
        Enemy newEnemy = Instantiate(_enemyPrefab, randomPointXZ + _playerTransform.position, Quaternion.identity);
        newEnemy.Setup(_playerTransform);
    }

    private void OnDrawGizmos()
    {
        if (_playerTransform)
        {
            Handles.color = Color.white;
            Handles.DrawWireDisc(_playerTransform.position, Vector3.up, _minRadius);
            Handles.color = Color.red;
            Handles.DrawWireDisc(_playerTransform.position, Vector3.up, _maxRadius);
        }
    }

}
