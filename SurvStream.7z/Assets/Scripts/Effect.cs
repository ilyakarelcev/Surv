using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Effect : ScriptableObject
{

    public Sprite _sprite;
    public string _name;
    public string _description;

    public abstract void Create(EffectsManager effectsManager);

}
